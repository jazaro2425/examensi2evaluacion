#!/bin/bash

#Ejercicio 1 (1.5 puntos): Cuenta
# Crea un script que dados dos números pasados por parámetros, muestre la cuenta de un a otro.
# Si el primero es mayor que el segundo, hará la cuenta del primero al segundo; al revés en caso contrario.
# Si son iguales, devolverá que no se puede hacer.

num1="$1"
num2="$2"

if [ "$#" -ne 2 ]; then
    echo "Uso: $0 numero1 numero2"
    exit 1
fi

if [ "$num1" -eq "$num2" ]; then
    echo " los numeros son iguales."
    exit 1
fi

if [ "$num1" -gt "$num2" ]; then
    for i in $(seq "$num1" -1 "$num2"); do
        echo "$i"
    done
else
    for i in $(seq "$num1" "$num2"); do
        echo "$i"
    done
fi
