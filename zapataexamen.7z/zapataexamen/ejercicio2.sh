#!/bin/bash

#Ejercicio 2 (1.5 puntos): Adivinar con pistas
#Crea un script para adivinar un número que el usuario introducirá por teclado.
#Hasta que no acierte el script se sigue ejecutando.
#En cada intento fallado el script devolverá si el número buscado es mayor o menor que el introducido.



echo "Dime un numero"
read numero_a_adivinar


prueba=0

while [ "$prueba" -ne "$adibinar" ]; do
    echo "Introduce tu intento:"
    read intento

    if [ "$int" -lt "$adibinar" ]; then
        echo "es mayor que $prueba"
    elif [ "$int" -gt "$adibinar" ]; then
        echo "es menor que $prueba"
    else
        echo "Has acertado"
    fi
done