#!/bin/bash

#Ejercicio 3: M.C.D (2 puntos).
#Calcula el máximo común divisor de dos números que se pasan por parámetros mediante el algoritmo de Euclides.
#Supongamos que los números son a y b (a es mayor que b).
#1) Dividimos a y b.
#2) Si el resto es = 0, b es el MCD.
#3) Si el resto es != 0, sustituimos a por b, b por el resto,
#y repetimos desde el paso 1 hasta que b sea = 0. Cuando ocurra eso a será el M.C.D.