#!/bin/bash
#Ejercicio 4 (1.5 puntos): Mayor y menor
#Obtén el nombre y la edad de la persona más mayor y más joven de datos.txt

#!/bin/bash


archivo="datos.txt"

mas_joven=$(sort -k2,2n "$archivo" | head -n 1)
mas_mayor=$(sort -k2,2nr "$archivo" | head -n 1)

echo "Persona más joven: $mas_joven"
echo "Persona más mayor: $mas_mayor"