#!/bin/bash
#Ejercicio 5 (1.5 puntos): Personas por ciudad
#Al pasarle por parámetro una ciudad, me devuelve cuántas hay en datos.txt

if [ "$#" -ne 1 ]; then
    echo "Uso: $0 <ciudad>"
    exit 1
fi

ciudad="$1"
conteo=$(grep -i "$ciudad" datos.txt | wc -l)

echo "En '$ciudad' hai $conteo"
